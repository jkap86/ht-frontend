import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../domain/league.dart';
import '../../domain/draft.dart';
import '../../domain/draft_helpers.dart';
import '../../application/drafts_provider.dart';
import '../../../../auth/application/auth_notifier.dart';
import '../../../../../core/services/socket/socket_providers.dart';
import 'derby/derby_countdown_widget.dart';
import 'derby/derby_slot_grid.dart';
import 'derby/derby_status_banner.dart';
import 'derby/derby_control_buttons.dart';
import 'draft_header_bar.dart';

/// Card showing draft overview with draft details
class DraftOverviewCard extends ConsumerWidget {
  final League league;

  const DraftOverviewCard({
    super.key,
    required this.league,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final draftsAsync = ref.watch(leagueDraftsProvider(league.id));

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Draft',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            draftsAsync.when(
              data: (drafts) {
                if (drafts.isEmpty) {
                  return const Padding(
                    padding: EdgeInsets.symmetric(vertical: 20),
                    child: Center(
                      child: Text(
                        'No drafts configured',
                        style: TextStyle(
                          fontSize: 14,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ),
                  );
                }

                // Show all drafts as collapsible cards
                return Column(
                  children: drafts.asMap().entries.map((entry) {
                    final index = entry.key;
                    final draft = entry.value;

                    return Padding(
                      padding: EdgeInsets.only(
                        bottom: index < drafts.length - 1 ? 16 : 0,
                      ),
                      child: _DraftCard(
                        draft: draft,
                        draftNumber: index + 1,
                        leagueId: league.id,
                        isCommissioner: league.isCommissioner,
                        league: league,
                      ),
                    );
                  }).toList(),
                );
              },
              loading: () => const Center(
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: CircularProgressIndicator(),
                ),
              ),
              error: (error, stack) => Padding(
                padding: const EdgeInsets.all(20),
                child: Text(
                  'Error loading draft info: $error',
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.error,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Individual draft card with collapsible sections
class _DraftCard extends ConsumerStatefulWidget {
  final Draft draft;
  final int draftNumber;
  final int leagueId;
  final bool isCommissioner;
  final League league;

  const _DraftCard({
    required this.draft,
    required this.draftNumber,
    required this.leagueId,
    required this.isCommissioner,
    required this.league,
  });

  @override
  ConsumerState<_DraftCard> createState() => _DraftCardState();
}

class _DraftCardState extends ConsumerState<_DraftCard> {
  bool _isExpanded = false;
  String? _expandedSection; // Track which section is expanded
  void Function()? _derbyUpdateListener;

  @override
  void initState() {
    super.initState();
    _setupDerbyUpdateListener();
  }

  @override
  void dispose() {
    _derbyUpdateListener?.call();
    super.dispose();
  }

  void _setupDerbyUpdateListener() {
    // Get the socket service and listen for derby updates
    final socketService = ref.read(socketServiceProvider);

    _derbyUpdateListener = socketService.on('derby_updated', (data) {
      if (data is Map<String, dynamic>) {
        final draftId = data['draft_id'];

        // Only refresh if this event is for our draft
        if (draftId == widget.draft.id) {
          print('[DraftOverviewCard] Derby updated for draft ${widget.draft.id}, refreshing...');

          // Refresh the draft order provider
          ref.invalidate(draftOrderProvider((leagueId: widget.leagueId, draftId: widget.draft.id)));

          // Also refresh the drafts list to get updated settings
          ref.invalidate(leagueDraftsProvider(widget.leagueId));
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final draftType = widget.draft.draftType;
    final rounds = widget.draft.rounds;
    final settings = widget.draft.settings;
    final playerPool = settings?.playerPool ?? 'all';

    return Card(
      elevation: 2,
      child: Column(
        children: [
          // Header - always visible
          DraftHeaderBar(
            draftName: 'Draft ${widget.draftNumber}',
            draftTypeLabel: DraftHelpers.formatDraftType(draftType),
            rounds: rounds,
            playerPoolLabel: DraftHelpers.formatPlayerPool(playerPool),
            isExpanded: _isExpanded,
            onToggleExpanded: () => setState(() => _isExpanded = !_isExpanded),
          ),

          // Expanded content - sections
          if (_isExpanded) ...[
            const Divider(height: 1),
            _buildDraftOrderSection(),
          ],
        ],
      ),
    );
  }

  Widget _buildDraftOrderSection() {
    final isExpanded = _expandedSection == 'draft_order';
    final settings = widget.draft.settings;
    final draftOrder = settings?.draftOrder ?? 'randomize';
    final draftOrderLabel =
        draftOrder.toLowerCase() == 'derby' ? 'Derby' : 'Randomize';

    return Column(
      children: [
        InkWell(
          onTap: () => setState(() {
            _expandedSection = isExpanded ? null : 'draft_order';
          }),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(
                  child: Row(
                    children: [
                      const Text(
                        'Draft Order',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.primaryContainer,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          draftOrderLabel,
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                            color: Theme.of(context)
                                .colorScheme
                                .onPrimaryContainer,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(
                  isExpanded ? Icons.expand_less : Icons.expand_more,
                  size: 20,
                ),
              ],
            ),
          ),
        ),
        if (isExpanded) ...[
          const Divider(height: 1),
          Padding(
            padding: const EdgeInsets.all(16),
            child: _buildDraftOrderContent(),
          ),
        ],
      ],
    );
  }

  Widget _buildDraftOrderContent() {
    final settings = widget.draft.settings;
    final draftOrder = settings?.draftOrder ?? 'randomize';
    final draftId = widget.draft.id;

    // Parse derby times and status
    final derbyStartTime = settings?.derbyStartTime;
    final derbyStatus = settings?.derbyStatus;
    final pickDeadline = widget.draft.pickDeadline;

    // Watch the draft order provider
    final draftOrderState = ref.watch(
        draftOrderProvider((leagueId: widget.leagueId, draftId: draftId)));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Derby countdown or notification (shown when derby order is selected)
        if (draftOrder.toLowerCase() == 'derby') ...[
          // If derby is in progress, show pick timer
          if (derbyStatus == 'in_progress' && pickDeadline != null)
            Container(
              padding: const EdgeInsets.all(12),
              margin: const EdgeInsets.only(bottom: 16),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.secondaryContainer,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color:
                      Theme.of(context).colorScheme.secondary.withOpacity(0.3),
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    Icons.timer,
                    color: Theme.of(context).colorScheme.secondary,
                    size: 20,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Time to pick:',
                          style: TextStyle(
                            fontSize: 12,
                            color: Theme.of(context)
                                .colorScheme
                                .onSecondaryContainer,
                          ),
                        ),
                        const SizedBox(height: 4),
                        DerbyCountdownWidget(targetTime: pickDeadline),
                      ],
                    ),
                  ),
                ],
              ),
            )
          // If derby hasn't started yet, show start countdown
          else if (derbyStartTime != null && derbyStatus != 'completed' && derbyStatus != 'in_progress')
            Container(
              padding: const EdgeInsets.all(12),
              margin: const EdgeInsets.only(bottom: 16),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primaryContainer,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: Theme.of(context).colorScheme.primary.withOpacity(0.3),
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    Icons.timer,
                    color: Theme.of(context).colorScheme.primary,
                    size: 20,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Derby starts in:',
                          style: TextStyle(
                            fontSize: 12,
                            color: Theme.of(context)
                                .colorScheme
                                .onPrimaryContainer,
                          ),
                        ),
                        const SizedBox(height: 4),
                        DerbyCountdownWidget(targetTime: derbyStartTime),
                      ],
                    ),
                  ),
                ],
              ),
            )
          else if (derbyStatus != 'completed' && derbyStatus != 'in_progress')
            Container(
              padding: const EdgeInsets.all(12),
              margin: const EdgeInsets.only(bottom: 16),
              decoration: BoxDecoration(
                color: Theme.of(context)
                    .colorScheme
                    .errorContainer
                    .withOpacity(0.3),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: Theme.of(context).colorScheme.error.withOpacity(0.3),
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    Icons.warning_amber_rounded,
                    color: Theme.of(context).colorScheme.error,
                    size: 20,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Derby start time not set',
                      style: TextStyle(
                        fontSize: 13,
                        color: Theme.of(context).colorScheme.onErrorContainer,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ),
        ],

        // Randomize/Start Derby button (only for commissioners)
        if (widget.isCommissioner &&
            derbyStatus != 'in_progress' &&
            derbyStatus != 'completed') ...[
          draftOrderState.when(
            data: (order) {
              // Show "Start Derby" button if order is randomized and draft type is derby
              if (order.isNotEmpty &&
                  draftOrder.toLowerCase() == 'derby' &&
                  derbyStatus != 'completed') {
                return Column(
                  children: [
                    FilledButton.icon(
                      onPressed: () async {
                        final scaffoldMessenger = ScaffoldMessenger.of(context);
                        try {
                          await ref
                              .read(draftOrderProvider((
                                leagueId: widget.leagueId,
                                draftId: draftId
                              )).notifier)
                              .startDerby();
                          // Refresh the drafts to get updated settings
                          ref.invalidate(leagueDraftsProvider(widget.leagueId));
                          scaffoldMessenger.showSnackBar(
                            const SnackBar(
                              content: Text(
                                  'Derby started! Users can now select their draft positions.'),
                            ),
                          );
                        } catch (e) {
                          scaffoldMessenger.showSnackBar(
                            SnackBar(
                              content: Text('Error starting derby: $e'),
                              backgroundColor:
                                  Theme.of(context).colorScheme.error,
                            ),
                          );
                        }
                      },
                      icon: const Icon(Icons.play_arrow),
                      label: const Text('Start Derby'),
                    ),
                    const SizedBox(height: 16),
                  ],
                );
              }

              // Show "Randomize" button if order is not randomized or not derby
              return Column(
                children: [
                  FilledButton.icon(
                    onPressed: draftOrderState.isLoading
                        ? null
                        : () async {
                            try {
                              await ref
                                  .read(draftOrderProvider((
                                    leagueId: widget.leagueId,
                                    draftId: draftId
                                  )).notifier)
                                  .randomize();
                            } catch (e) {
                              if (mounted) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                        'Error randomizing draft order: $e'),
                                    backgroundColor:
                                        Theme.of(context).colorScheme.error,
                                  ),
                                );
                              }
                            }
                          },
                    icon: const Icon(Icons.shuffle),
                    label: Text(
                      draftOrder.toLowerCase() == 'derby'
                          ? 'Randomize Derby Order'
                          : 'Randomize Draft Order',
                    ),
                  ),
                  const SizedBox(height: 16),
                ],
              );
            },
            loading: () => const Column(
              children: [
                CircularProgressIndicator(),
                SizedBox(height: 16),
              ],
            ),
            error: (_, __) => Column(
              children: [
                FilledButton.icon(
                  onPressed: null,
                  icon: const Icon(Icons.shuffle),
                  label: const Text('Randomize Draft Order'),
                ),
                const SizedBox(height: 16),
              ],
            ),
          ),
        ],
        // Draft order list or slot selection
        draftOrderState.when(
          data: (order) {
            if (order.isEmpty) {
              return const Center(
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Text(
                    'Click the button above to randomize draft order',
                    style: TextStyle(
                      fontSize: 14,
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                ),
              );
            }

            // If derby is in progress or paused, show slot selection UI
            if ((derbyStatus == 'in_progress' || derbyStatus == 'paused') &&
                draftOrder.toLowerCase() == 'derby') {
              final currentPickerIndex = settings?.currentPickerIndex ?? 0;

              // Validate that currentPickerIndex is within bounds
              if (order.isEmpty || currentPickerIndex >= order.length) {
                return const Padding(
                  padding: EdgeInsets.all(16.0),
                  child: Text('Invalid draft state. Please refresh.'),
                );
              }

              final currentPicker = order[currentPickerIndex];
              final currentPickerUserId = currentPicker['userId']?.toString();

              // Get current user's ID to check if it's their turn
              final authState = ref.watch(authProvider);
              final currentUserId = authState.user?.userId;
              final isMyTurn =
                  currentUserId != null && currentPickerUserId == currentUserId;

              // Create a map of taken positions
              // Include all users who have picked a slot (draftPosition is not null)
              final takenPositions = <int, Map<String, dynamic>>{};
              for (int i = 0; i < order.length; i++) {
                final item = order[i];
                final position = item['draftPosition'] as int?;
                if (position != null) {
                  takenPositions[position] = item;
                }
              }

              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Derby pick order
                  Container(
                    padding: const EdgeInsets.all(12),
                    margin: const EdgeInsets.only(bottom: 16),
                    decoration: BoxDecoration(
                      color:
                          Theme.of(context).colorScheme.surfaceContainerHighest,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: Theme.of(context)
                            .colorScheme
                            .outline
                            .withValues(alpha: 0.3),
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Derby Pick Order',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color:
                                Theme.of(context).colorScheme.onSurfaceVariant,
                          ),
                        ),
                        const SizedBox(height: 8),
                        ...order.asMap().entries.map((entry) {
                          final index = entry.key;
                          final item = entry.value;
                          final username = item['username'] as String? ??
                              'Team ${item['rosterNumber']}';
                          final isCurrent = index == currentPickerIndex;
                          final hasPicked = index < currentPickerIndex;
                          final slotNumber = item['draftPosition'] as int?;

                          return Padding(
                            padding: const EdgeInsets.only(bottom: 4),
                            child: Row(
                              children: [
                                Container(
                                  width: 24,
                                  height: 24,
                                  decoration: BoxDecoration(
                                    color: isCurrent
                                        ? Theme.of(context).colorScheme.primary
                                        : hasPicked
                                            ? Theme.of(context)
                                                .colorScheme
                                                .primaryContainer
                                            : Theme.of(context)
                                                .colorScheme
                                                .surfaceContainer,
                                    shape: BoxShape.circle,
                                  ),
                                  child: Center(
                                    child: Text(
                                      '${index + 1}',
                                      style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold,
                                        color: isCurrent
                                            ? Theme.of(context)
                                                .colorScheme
                                                .onPrimary
                                            : hasPicked
                                                ? Theme.of(context)
                                                    .colorScheme
                                                    .onPrimaryContainer
                                                : Theme.of(context)
                                                    .colorScheme
                                                    .onSurfaceVariant,
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    username,
                                    style: TextStyle(
                                      fontSize: 13,
                                      fontWeight: isCurrent
                                          ? FontWeight.w600
                                          : FontWeight.normal,
                                      color: isCurrent
                                          ? Theme.of(context)
                                              .colorScheme
                                              .primary
                                          : Theme.of(context)
                                              .colorScheme
                                              .onSurfaceVariant,
                                    ),
                                  ),
                                ),
                                if (slotNumber != null)
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .primaryContainer,
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Text(
                                      'Slot $slotNumber',
                                      style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold,
                                        color: Theme.of(context)
                                            .colorScheme
                                            .onPrimaryContainer,
                                      ),
                                    ),
                                  ),
                              ],
                            ),
                          );
                        }).toList(),
                      ],
                    ),
                  ),

                  // Current picker info
                  DerbyStatusBanner(
                    isMyTurn: isMyTurn,
                    currentPickerName: currentPicker['username'] ?? 'player',
                  ),

                  // Commissioner pause/resume button
                  if (widget.isCommissioner)
                    DerbyControlButtons(
                      derbyStatus: derbyStatus ?? '',
                      showStartButton: false,
                      onPause: () async {
                        try {
                          await ref
                              .read(draftOrderProvider((
                                leagueId: widget.leagueId,
                                draftId: draftId
                              )).notifier)
                              .pauseDerby();
                          ref.invalidate(leagueDraftsProvider(widget.leagueId));
                        } catch (e) {
                          if (mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text('Error: $e'),
                                backgroundColor:
                                    Theme.of(context).colorScheme.error,
                              ),
                            );
                          }
                        }
                      },
                      onResume: () async {
                        try {
                          await ref
                              .read(draftOrderProvider((
                                leagueId: widget.leagueId,
                                draftId: draftId
                              )).notifier)
                              .resumeDerby();
                          ref.invalidate(leagueDraftsProvider(widget.leagueId));
                        } catch (e) {
                          if (mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text('Error: $e'),
                                backgroundColor:
                                    Theme.of(context).colorScheme.error,
                              ),
                            );
                          }
                        }
                      },
                      onStart: () {
                        // Not used in this context
                      },
                    ),

                  // Slot selection grid
                  DerbySlotGrid(
                    draftOrder: order,
                    takenPositions: takenPositions,
                    isMyTurn: isMyTurn,
                    derbyStatus: derbyStatus ?? '',
                    onSlotSelected: (slotNumber) async {
                      try {
                        await ref
                            .read(draftOrderProvider((
                              leagueId: widget.leagueId,
                              draftId: draftId
                            )).notifier)
                            .pickSlot(slotNumber);
                        ref.invalidate(leagueDraftsProvider(widget.leagueId));
                      } catch (e) {
                        if (mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text('Error picking slot: $e'),
                              backgroundColor:
                                  Theme.of(context).colorScheme.error,
                            ),
                          );
                        }
                      }
                    },
                  ),
                ],
              );
            }

            // If derby is completed, show final order sorted by derby slots
            if (draftOrder.toLowerCase() == 'derby' &&
                derbyStatus == 'completed' &&
                order.isNotEmpty) {
              bool sortByDraftOrder = true; // Closure variable

              return StatefulBuilder(
                builder: (context, setBuilderState) {
                  // Create a map of original picking order (index + 1) for each user
                  final pickingOrderMap = <String, int>{};
                  for (int i = 0; i < order.length; i++) {
                    final rosterId = order[i]['rosterId']?.toString() ?? '';
                    if (rosterId.isNotEmpty) {
                      pickingOrderMap[rosterId] = i + 1;
                    }
                  }

                  // Sort based on selected option
                  final sortedOrder = List<Map<String, dynamic>>.from(order);
                  if (sortByDraftOrder) {
                    // Sort by draft order (draft_position)
                    sortedOrder.sort((a, b) {
                      final posA = (a['draftPosition'] as int?) ?? 999;
                      final posB = (b['draftPosition'] as int?) ?? 999;
                      return posA.compareTo(posB);
                    });
                  } else {
                    // Sort by derby slot (original picking order)
                    sortedOrder.sort((a, b) {
                      final rosterIdA = a['rosterId']?.toString() ?? '';
                      final rosterIdB = b['rosterId']?.toString() ?? '';
                      final derbySlotA = pickingOrderMap[rosterIdA] ?? 999;
                      final derbySlotB = pickingOrderMap[rosterIdB] ?? 999;
                      return derbySlotA.compareTo(derbySlotB);
                    });
                  }

                  return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    margin: const EdgeInsets.only(bottom: 16),
                    decoration: BoxDecoration(
                      color:
                          Theme.of(context).colorScheme.surfaceContainerHighest,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: Theme.of(context)
                            .colorScheme
                            .outline
                            .withValues(alpha: 0.3),
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Final Draft Order',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: Theme.of(context).colorScheme.primary,
                          ),
                        ),
                        const SizedBox(height: 12),
                        // Header row
                        Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: Row(
                            children: [
                              SizedBox(
                                width: 80,
                                child: InkWell(
                                  onTap: () {
                                    setBuilderState(() {
                                      sortByDraftOrder = false;
                                    });
                                  },
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        'Derby Slot',
                                        style: TextStyle(
                                          fontSize: 11,
                                          fontWeight: FontWeight.bold,
                                          color: !sortByDraftOrder
                                              ? Theme.of(context).colorScheme.primary
                                              : Theme.of(context)
                                                  .colorScheme
                                                  .onSurfaceVariant,
                                        ),
                                      ),
                                      if (!sortByDraftOrder)
                                        Icon(
                                          Icons.arrow_drop_down,
                                          size: 16,
                                          color: Theme.of(context).colorScheme.primary,
                                        ),
                                    ],
                                  ),
                                ),
                              ),
                              Expanded(
                                child: Text(
                                  'Team',
                                  style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold,
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onSurfaceVariant,
                                  ),
                                ),
                              ),
                              SizedBox(
                                width: 80,
                                child: InkWell(
                                  onTap: () {
                                    setBuilderState(() {
                                      sortByDraftOrder = true;
                                    });
                                  },
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      Text(
                                        'Draft Order',
                                        textAlign: TextAlign.right,
                                        style: TextStyle(
                                          fontSize: 11,
                                          fontWeight: FontWeight.bold,
                                          color: sortByDraftOrder
                                              ? Theme.of(context).colorScheme.primary
                                              : Theme.of(context)
                                                  .colorScheme
                                                  .onSurfaceVariant,
                                        ),
                                      ),
                                      if (sortByDraftOrder)
                                        Icon(
                                          Icons.arrow_drop_down,
                                          size: 16,
                                          color: Theme.of(context).colorScheme.primary,
                                        ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const Divider(height: 1),
                        const SizedBox(height: 8),
                        ...sortedOrder.map((item) {
                          final draftSlot = item['draftPosition'] as int?;
                          final rosterId = item['rosterId']?.toString() ?? '';
                          final derbySlot = pickingOrderMap[rosterId];
                          final username = item['username'] as String? ??
                              'Team ${item['rosterNumber']}';

                          if (draftSlot == null) return const SizedBox.shrink();

                          return Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 80,
                                  child: Text(
                                    derbySlot != null ? '#$derbySlot' : '-',
                                    style: TextStyle(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w500,
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurfaceVariant,
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 8),
                                    child: Text(
                                      username,
                                      style: const TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  width: 80,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .primaryContainer,
                                      borderRadius: BorderRadius.circular(4),
                                    ),
                                    child: Text(
                                      'Slot $draftSlot',
                                      textAlign: TextAlign.right,
                                      style: TextStyle(
                                        fontSize: 13,
                                        fontWeight: FontWeight.bold,
                                        color: Theme.of(context)
                                            .colorScheme
                                            .onPrimaryContainer,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        }),
                      ],
                    ),
                  ),
                  // Draft Room button
                  const SizedBox(height: 16),
                  Center(
                    child: FilledButton.icon(
                      onPressed: () {
                        context.goNamed(
                          'draft-room',
                          pathParameters: {
                            'leagueId': widget.league.id.toString(),
                            'draftId': widget.draft.id.toString(),
                          },
                        );
                      },
                      icon: const Icon(Icons.meeting_room),
                      label: const Text('Enter Draft Room'),
                    ),
                  ),
                ],
                  );
                },
              );
            }

            // If derby is randomized but not started, show picking order
            if (draftOrder.toLowerCase() == 'derby' &&
                order.isNotEmpty &&
                derbyStatus != 'in_progress' &&
                derbyStatus != 'paused' &&
                derbyStatus != 'completed') {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    margin: const EdgeInsets.only(bottom: 16),
                    decoration: BoxDecoration(
                      color:
                          Theme.of(context).colorScheme.surfaceContainerHighest,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: Theme.of(context)
                            .colorScheme
                            .outline
                            .withValues(alpha: 0.3),
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Derby Pick Order',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: Theme.of(context).colorScheme.primary,
                          ),
                        ),
                        const SizedBox(height: 12),
                        ...order.asMap().entries.map((entry) {
                          final index = entry.key;
                          final item = entry.value;
                          final username = item['username'] as String? ??
                              'Team ${item['rosterNumber']}';
                          final isCurrent = index == 0;

                          return Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: Row(
                              children: [
                                Container(
                                  width: 32,
                                  height: 32,
                                  decoration: BoxDecoration(
                                    color: isCurrent
                                        ? Theme.of(context).colorScheme.primary
                                        : Theme.of(context)
                                            .colorScheme
                                            .primaryContainer,
                                    shape: BoxShape.circle,
                                  ),
                                  child: Center(
                                    child: Text(
                                      '${index + 1}',
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: isCurrent
                                            ? Theme.of(context)
                                                .colorScheme
                                                .onPrimary
                                            : Theme.of(context)
                                                .colorScheme
                                                .onPrimaryContainer,
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Text(
                                    username,
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: isCurrent
                                          ? FontWeight.bold
                                          : FontWeight.w500,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        }),
                      ],
                    ),
                  ),
                ],
              );
            }

            // Normal draft order display
            return Column(
              children: order
                  .where((item) => item['draftPosition'] != null)
                  .map((item) {
                final position = (item['draftPosition'] as num?)?.toInt() ?? 0;
                final username = item['username'] as String? ??
                    'Team ${item['rosterNumber']}';

                return Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    children: [
                      Container(
                        width: 32,
                        height: 32,
                        decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.primaryContainer,
                          shape: BoxShape.circle,
                        ),
                        child: Center(
                          child: Text(
                            '$position',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Theme.of(context)
                                  .colorScheme
                                  .onPrimaryContainer,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          username,
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            );
          },
          loading: () => const Center(
            child: Padding(
              padding: EdgeInsets.all(20),
              child: CircularProgressIndicator(),
            ),
          ),
          error: (error, stack) => Center(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Text(
                'Error loading draft order: $error',
                style: TextStyle(
                  color: Theme.of(context).colorScheme.error,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
